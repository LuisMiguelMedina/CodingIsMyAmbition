## Défi

Écrivez une fonction qui prend une `String` en entrée et la renvoie en majuscules.

## Arguments

* `input` : une `String` contenant un texte aléatoire (type lorem ipsum).

## Base de travail

```js
function upperCaser(input) {
  // VOTRE SOLUTION ICI
}

module.exports = upperCaser
```
