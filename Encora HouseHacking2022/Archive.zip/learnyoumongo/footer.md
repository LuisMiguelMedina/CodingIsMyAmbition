__»__ To print these instructions again, run: `{appname} print`
__»__ To run your program, run: `{appname} run [solution.js]`
__»__ To verify your program, run: `{appname} verify [solution.js]`
__»__ For help run: `{appname} help`
