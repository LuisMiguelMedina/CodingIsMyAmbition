欢迎使用 `learnyoumongo` 教程. 首先，先装上MongoDB数据库。
您可以通过 `https://www.mongodb.org/downloads` 下载 MongoDB。

然后，我们必须确保MongoDB已经加入到 `$PATH`中。

本堂课不需要创建回答档案。当您完成安装，运行 `learnyoumongo verify` 。

-----------------------------------------------------------
## 提示

为了验证您成功安装了`mongod`，您可以尝试运行 `mongod --version`。

如果您是使用Windows操作系统，您可以使用`mongod.exe`。

运行后，您应该会看到类似下列的回复：

```
db version v3.2.11
git version: 009580ad490190ba33d1c6253ebd8d91808923e4
```
