Saludos de `learnyoumongo`. Primero, vamos a instalar MongoDB.
Puedes descargar MongoDB de `https://www.mongodb.org/downloads`.

Tendremos que añadirlo a tu `$PATH`.

No tienes que crear ningún archivo con una solución en este
ejercicio. Simplemente ejecuta `learnyoumongo verify` cuando
hayas cumplido con la instalación.

-----------------------------------------------------------
## PISTAS

Para verificar que `mongod` se instaló bien, puedes ejecutar
`mongod --version`.

Si estás usando Windows, tendrás que usar `mongod.exe`.

Debería imprimir algo así:

```
db version v2.6.8
2015-05-06T09:44:39.362-0500 git version: nogitversion
```
