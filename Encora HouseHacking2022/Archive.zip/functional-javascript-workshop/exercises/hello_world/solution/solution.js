module.exports = function(input) {
  return input.toUpperCase()
}
