#Más Práticas

O objetivo desse exercício é aprender a identificar más práticas no código. Primeiro, faça o 'Quiz de boas práticas' localizado
na parte de baixo do menu. Após isso, abra o 'balanceManager.js' e conserte os erros que você encontrar.

Ambos os exercícios foram escritos com base no Curriculum de Boas práticas de Javascript, que pode ser encontrado aqui: 
https://github.com/excellalabs/the-javascript-curriculum. Pode ser uma boa idéia olhar esse material, caso ainda não o tenha feito.