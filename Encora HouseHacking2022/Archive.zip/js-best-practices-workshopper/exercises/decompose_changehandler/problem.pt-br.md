# Separação de Preocupações (SoC) 2
Esse é o segundo exercício para demonstrar o conceito de Separação de Preocupações (ou Conceitos).

Nós já separamos todos os métodos relacionados ao caixa, agora iremos olhar para os métodos relacionados com as trocas. Pegue os métodos relacionados a tratar as trocas e mova para dentro do 'changeHandler.js'.

Assim como no exercício anterior, garanta que o novo 'changeHandler' esteja chamando as funções, rode os testes, agora você tem integrado com sucesso um 'changeHandler' para sua máquina de vendas.
