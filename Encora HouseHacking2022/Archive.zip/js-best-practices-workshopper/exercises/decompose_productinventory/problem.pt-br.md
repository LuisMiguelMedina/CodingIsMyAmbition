# Separação de Preocupações (SoC) 3
Essa é a terceira e última parte do exercício que ensina o conceito de Separação de Preocupações (ou Conceitos).

Nós já separamos todos os métodos relacionados ao caixa e as trocas, falta apenas um (não contando com a máquina de vendas) que será os produtos. Pegue os dois métodos realacionados aos produtos e mova para dentro do 'productInventory.js'.

Garanta que o novo 'productInventory' esteja chamando as funções, rode os testes, você terá a máquina de vendas com as preocupações completamente separadas.
