# Começando

O objetivo desse workshopper é ajudar você a aprender como criar uma base de código resiliente usando boas práticas.
O workshopper irá te guiar através de alguns exercícios que irão te auxiliar a realizar melhorias incrementais a 
uma base de código ruim. Através dos exercícios, você aprenderá boas práticas que te ajudarão a ter um código de 
fácil manutenção, como também a evitar más práticas.

Você estará fazendo mudanças a um aplicativo de uma máquina de vendas. Você receberá um arquivo chamado 'vendingMachine.js'
como alguns outros arquivos js vazios. Nos próximos exercícios você irá quebrar em partes a máquina de vendas e transformá-la 
em um programa que ainda funciona da mesma forma, porém de fácil manutenção, testes, e melhorias.

Quando você sair dessa tela de instruções, os arquivos necessários serão baixados para você. 
