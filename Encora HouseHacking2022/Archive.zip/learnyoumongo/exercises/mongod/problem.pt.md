Oi Oi do `learnyoumongo`. Primeiramente vamos instalar o MongoDB.
O download pode ser realizado `https://www.mongodb.org/downloads`.

Tambem e' necessario inclui-lo no `$PATH`.

Nao e' necessario criar arquivos com respostas nesse exercicio.
Apenas rode `learnyoumongo verify` quando a instalao estiver pronta.

-----------------------------------------------------------
## DICAS

Para verificar se `mongod` esta' instalado, execute `mongod --version`.

Se for usuario Windows, utilize `mongod.exe`.

Devera' aparecer algo parecido com:

```
db version v2.6.8
2015-05-06T09:44:39.362-0500 git version: nogitversion
```
