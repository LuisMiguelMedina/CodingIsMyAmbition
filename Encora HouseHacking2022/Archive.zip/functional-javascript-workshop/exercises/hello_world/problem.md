# Task

Write a function that takes an input string and returns it uppercased.

## Arguments

* input: a String of random words (lorem ipsum).

## Boilerplate

```js
function upperCaser(input) {
  // SOLUTION GOES HERE
}

module.exports = upperCaser
```
